export const createGeometry = {
    data() {
        return {
        }
    },
    methods: {
 
    }
}